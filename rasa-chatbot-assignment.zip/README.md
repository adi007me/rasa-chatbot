# Foodie Chaatbot
An Indian startup named 'Foodie' wants to build a conversational bot (chatbot) which can help users discover restaurants across several Indian cities.
The main purpose of the bot is to help users discover restaurants quickly and efficiently and to provide a good restaurant discovery experience

## Dependencies
- Python 3.7.4
- Rasa 1.10.15
- Spacy

## Authors
* Aditya Bhave
* Sivaprasad